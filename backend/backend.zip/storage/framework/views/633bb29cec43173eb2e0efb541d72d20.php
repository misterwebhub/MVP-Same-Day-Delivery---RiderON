<?php $__env->startSection('title', 'Refunds'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusColors = [
            'pending' => 'bg-warning/10 text-warning',
            'approved' => 'bg-info/10 text-info',
            'processing' => 'bg-info/10 text-info',
            'completed' => 'bg-success/10 text-success',
            'rejected' => 'bg-danger/10 text-danger',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Refunds</h2>
            <p class="page-subtitle">Review and process customer refund requests.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <select name="status" class="form-input w-48">
                <option value="">All statuses</option>
                <option value="pending" <?php if(($filters['status'] ?? '') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                <option value="approved" <?php if(($filters['status'] ?? '') === 'approved'): echo 'selected'; endif; ?>>Approved</option>
                <option value="processing" <?php if(($filters['status'] ?? '') === 'processing'): echo 'selected'; endif; ?>>Processing</option>
                <option value="completed" <?php if(($filters['status'] ?? '') === 'completed'): echo 'selected'; endif; ?>>Completed</option>
                <option value="rejected" <?php if(($filters['status'] ?? '') === 'rejected'): echo 'selected'; endif; ?>>Rejected</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Requested by</th>
                    <th>Reason</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Provider ref</th>
                    <th>Approved by</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($refund->order?->booking_reference); ?></td>
                        <td><span class="badge bg-border text-text-secondary"><?php echo e(ucfirst($refund->requested_by)); ?></span></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($refund->reason, 40)); ?></td>
                        <td>₹<?php echo e(number_format($refund->amount_paise / 100, 2)); ?></td>
                        <td>
                            <span class="badge <?php echo e($statusColors[$refund->status] ?? 'bg-border text-text-secondary'); ?>">
                                <?php echo e(ucfirst($refund->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($refund->provider_refund_id ?? '—'); ?></td>
                        <td><?php echo e($refund->approvedBy?->name ?? '—'); ?></td>
                        <td class="text-right">
                            <a href="<?php echo e(route('admin.refunds.show', $refund)); ?>" class="link-quiet">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">
                            <div class="empty-state">No refunds found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($refunds->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/refunds/index.blade.php ENDPATH**/ ?>