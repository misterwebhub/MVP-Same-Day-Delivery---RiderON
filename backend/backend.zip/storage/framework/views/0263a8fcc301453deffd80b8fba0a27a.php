<?php $__env->startSection('title', 'Cities'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h2 class="page-title">Cities</h2>
            <p class="page-subtitle">Manage delivery cities and coverage areas.</p>
        </div>
        <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
            <a href="<?php echo e(route('admin.cities.create')); ?>" class="btn-primary">Add city</a>
        <?php endif; ?>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Search name or state" class="form-input w-64">
            <select name="trashed" class="form-input w-40">
                <option value="">Active only</option>
                <option value="with" <?php if(($filters['trashed'] ?? null) === 'with'): echo 'selected'; endif; ?>>With trashed</option>
                <option value="only" <?php if(($filters['trashed'] ?? null) === 'only'): echo 'selected'; endif; ?>>Trashed only</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>State</th>
                    <th>Active</th>
                    <th>Created</th>
                    <th>Deleted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($city->name); ?></td>
                        <td><?php echo e($city->state); ?></td>
                        <td>
                            <span class="badge <?php echo e($city->is_active ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'); ?>">
                                <?php echo e($city->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="text-caption text-text-secondary"><?php echo e($city->created_at?->format('Y-m-d H:i')); ?></td>
                        <td class="text-caption text-text-secondary"><?php echo e($city->deleted_at?->format('Y-m-d H:i') ?? '—'); ?></td>
                        <td class="text-right">
                            <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
                                <?php if($city->trashed()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.cities.restore', $city->id)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="link-quiet text-info">Restore</button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.cities.force-delete', $city->id)); ?>" class="inline" onsubmit="return confirm('Permanently delete this city? This cannot be undone.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Force delete</button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.cities.edit', $city)); ?>" class="link-quiet">Edit</a>
                                    <form method="POST" action="<?php echo e(route('admin.cities.destroy', $city)); ?>" class="inline" onsubmit="return confirm('Delete this city?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">No cities found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($cities->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/cities/index.blade.php ENDPATH**/ ?>