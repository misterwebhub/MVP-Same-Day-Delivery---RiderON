<?php $__env->startSection('title', 'Support tickets'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusColors = [
            'open' => 'bg-danger/10 text-danger',
            'in_progress' => 'bg-warning/10 text-warning',
            'resolved' => 'bg-success/10 text-success',
            'closed' => 'bg-success/10 text-success',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Support tickets</h2>
            <p class="page-subtitle">Respond to and resolve customer support requests.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex flex-wrap items-center gap-2">
            <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Search ticket number" class="form-input w-56">
            <select name="status" class="form-input w-40">
                <option value="">All statuses</option>
                <option value="open" <?php if(($filters['status'] ?? '') === 'open'): echo 'selected'; endif; ?>>Open</option>
                <option value="in_progress" <?php if(($filters['status'] ?? '') === 'in_progress'): echo 'selected'; endif; ?>>In progress</option>
                <option value="resolved" <?php if(($filters['status'] ?? '') === 'resolved'): echo 'selected'; endif; ?>>Resolved</option>
                <option value="closed" <?php if(($filters['status'] ?? '') === 'closed'): echo 'selected'; endif; ?>>Closed</option>
            </select>
            <select name="category" class="form-input w-48">
                <option value="">All categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(($filters['category'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Ticket #</th>
                    <th>Customer</th>
                    <th>Order</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Assigned to</th>
                    <th>Created</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium"><?php echo e($ticket->ticket_number); ?></td>
                        <td><?php echo e($ticket->customer?->name); ?></td>
                        <td><?php echo e($ticket->order?->booking_reference ?? '—'); ?></td>
                        <td><span class="badge bg-border text-text-secondary"><?php echo e($categories[$ticket->category] ?? $ticket->category); ?></span></td>
                        <td>
                            <span class="badge <?php echo e($statusColors[$ticket->status] ?? 'bg-border text-text-secondary'); ?>">
                                <?php echo e($categories[$ticket->status] ?? ucwords(str_replace('_', ' ', $ticket->status))); ?>

                            </span>
                        </td>
                        <td><?php echo e($ticket->assignedTo?->name ?? 'Unassigned'); ?></td>
                        <td><?php echo e($ticket->created_at); ?></td>
                        <td class="text-right">
                            <a href="<?php echo e(route('admin.support-tickets.edit', $ticket)); ?>" class="link-quiet">Manage</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">
                            <div class="empty-state">No support tickets found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($tickets->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/support-tickets/index.blade.php ENDPATH**/ ?>