<?php $__env->startSection('title', 'Activity & notifications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h2 class="page-title">Activity & notifications</h2>
            <p class="page-subtitle">Everything the system has told a customer, partner, or admin — OTP regenerations, new assignments, and more.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <select name="type" class="form-input w-56">
                <option value="">All types</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type); ?>" <?php if(($filters['type'] ?? '') === $type): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_', ' ', $type))); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="channel" class="form-input w-40">
                <option value="">All channels</option>
                <option value="push" <?php if(($filters['channel'] ?? '') === 'push'): echo 'selected'; endif; ?>>Push</option>
                <option value="in_app" <?php if(($filters['channel'] ?? '') === 'in_app'): echo 'selected'; endif; ?>>In-app (admin)</option>
                <option value="sms" <?php if(($filters['channel'] ?? '') === 'sms'): echo 'selected'; endif; ?>>SMS</option>
                <option value="whatsapp" <?php if(($filters['channel'] ?? '') === 'whatsapp'): echo 'selected'; endif; ?>>WhatsApp</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>When</th>
                    <th>Type</th>
                    <th>Recipient</th>
                    <th>Channel</th>
                    <th>Title / body</th>
                    <th>Delivered</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($n->created_at); ?></td>
                        <td><span class="badge bg-border text-text-secondary"><?php echo e(ucfirst(str_replace('_', ' ', $n->type))); ?></span></td>
                        <td><?php echo e($n->user?->name ?? '—'); ?> <span class="text-text-secondary">(<?php echo e(ucfirst($n->user?->role ?? '—')); ?>)</span></td>
                        <td><?php echo e(ucfirst(str_replace('_', ' ', $n->channel))); ?></td>
                        <td>
                            <div class="text-body-strong"><?php echo e($n->title); ?></div>
                            <div class="text-caption text-text-secondary"><?php echo e($n->body); ?></div>
                        </td>
                        <td>
                            <?php if($n->channel !== 'push'): ?>
                                <span class="badge bg-border text-text-secondary">N/A</span>
                            <?php elseif($n->sent_at): ?>
                                <span class="badge bg-success/10 text-success">Sent <?php echo e($n->sent_at); ?></span>
                            <?php else: ?>
                                <span class="badge bg-warning/10 text-warning">No device</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">No activity yet.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($notifications->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>