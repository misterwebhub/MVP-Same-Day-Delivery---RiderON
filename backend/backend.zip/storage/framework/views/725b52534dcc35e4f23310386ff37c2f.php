<?php $__env->startSection('title', 'OTP verification logs'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $resultColors = [
            'success' => 'bg-success/10 text-success',
            'invalid' => 'bg-danger/10 text-danger',
            'expired' => 'bg-warning/10 text-warning',
            'locked' => 'bg-danger/10 text-danger',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">OTP verification logs</h2>
            <p class="page-subtitle">Audit trail of OTP verification attempts.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <select name="result" class="form-input w-40">
                <option value="">All results</option>
                <option value="success" <?php if(($filters['result'] ?? '') === 'success'): echo 'selected'; endif; ?>>Success</option>
                <option value="invalid" <?php if(($filters['result'] ?? '') === 'invalid'): echo 'selected'; endif; ?>>Invalid</option>
                <option value="expired" <?php if(($filters['result'] ?? '') === 'expired'): echo 'selected'; endif; ?>>Expired</option>
                <option value="locked" <?php if(($filters['result'] ?? '') === 'locked'): echo 'selected'; endif; ?>>Locked</option>
            </select>
            <select name="attempted_by_type" class="form-input w-40">
                <option value="">All actors</option>
                <option value="customer" <?php if(($filters['attempted_by_type'] ?? '') === 'customer'): echo 'selected'; endif; ?>>Customer</option>
                <option value="partner" <?php if(($filters['attempted_by_type'] ?? '') === 'partner'): echo 'selected'; endif; ?>>Partner</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Phone</th>
                    <th>Purpose</th>
                    <th>Attempted by</th>
                    <th>Result</th>
                    <th>IP address</th>
                    <th>When</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($log->otpVerification?->phone ?? '—'); ?></td>
                        <td><?php echo e(ucfirst($log->otpVerification?->purpose ?? '—')); ?></td>
                        <td><span class="badge bg-border text-text-secondary"><?php echo e(ucfirst($log->attempted_by_type)); ?></span></td>
                        <td>
                            <span class="badge <?php echo e($resultColors[$log->result] ?? 'bg-border text-text-secondary'); ?>">
                                <?php echo e(ucfirst($log->result)); ?>

                            </span>
                        </td>
                        <td><?php echo e($log->ip_address ?? '—'); ?></td>
                        <td><?php echo e($log->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">No OTP verification logs found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($logs->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/otp-logs/index.blade.php ENDPATH**/ ?>