<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusColors = [
            'active' => 'bg-success/10 text-success',
            'suspended' => 'bg-danger/10 text-danger',
            'deleted' => 'bg-border text-text-secondary',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Customers</h2>
            <p class="page-subtitle">View and manage registered customer accounts.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Search name, phone, or email" class="form-input w-64">
            <select name="status" class="form-input w-40">
                <option value="">All statuses</option>
                <option value="active" <?php if(($filters['status'] ?? '') === 'active'): echo 'selected'; endif; ?>>Active</option>
                <option value="suspended" <?php if(($filters['status'] ?? '') === 'suspended'): echo 'selected'; endif; ?>>Suspended</option>
                <option value="deleted" <?php if(($filters['status'] ?? '') === 'deleted'): echo 'selected'; endif; ?>>Deleted</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Orders</th>
                    <th>Joined</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><?php echo e($customer->email ?? '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($statusColors[$customer->status] ?? 'bg-border text-text-secondary'); ?>">
                                <?php echo e(ucfirst($customer->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($customer->ordersAsCustomer()->count()); ?></td>
                        <td class="text-caption text-text-secondary"><?php echo e($customer->created_at?->format('Y-m-d H:i')); ?></td>
                        <td class="text-right">
                            <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
                                <a href="<?php echo e(route('admin.customers.edit', $customer)); ?>" class="link-quiet">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">No customers found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($customers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>