<?php $__env->startSection('title', 'Delivery partners'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $verificationColors = [
            'pending' => 'bg-warning/10 text-warning',
            'verified' => 'bg-success/10 text-success',
            'rejected' => 'bg-danger/10 text-danger',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Delivery partners</h2>
            <p class="page-subtitle">Manage rider accounts, verification, and availability.</p>
        </div>
        <?php if(\App\Support\AdminAccess::canManageOrders()): ?>
            <a href="<?php echo e(route('admin.delivery-partners.create')); ?>" class="btn-primary">Add delivery partner</a>
        <?php endif; ?>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Search partner code" class="form-input w-56">
            <select name="verification_status" class="form-input w-40">
                <option value="">All statuses</option>
                <option value="pending" <?php if(($filters['verification_status'] ?? '') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                <option value="verified" <?php if(($filters['verification_status'] ?? '') === 'verified'): echo 'selected'; endif; ?>>Verified</option>
                <option value="rejected" <?php if(($filters['verification_status'] ?? '') === 'rejected'): echo 'selected'; endif; ?>>Rejected</option>
            </select>
            <select name="trashed" class="form-input w-40">
                <option value="">Active only</option>
                <option value="with" <?php if(($filters['trashed'] ?? null) === 'with'): echo 'selected'; endif; ?>>With trashed</option>
                <option value="only" <?php if(($filters['trashed'] ?? null) === 'only'): echo 'selected'; endif; ?>>Trashed only</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Code</th>
                    <th>Vehicle</th>
                    <th>Verification</th>
                    <th>Rating</th>
                    <th>Deliveries</th>
                    <th>Home city</th>
                    <th>Active</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($partner->user?->name); ?></td>
                        <td><?php echo e($partner->partner_code); ?></td>
                        <td><?php echo e(ucfirst(str_replace('_', ' ', $partner->vehicle_type))); ?></td>
                        <td>
                            <span class="badge <?php echo e($verificationColors[$partner->verification_status] ?? 'bg-border text-text-secondary'); ?>">
                                <?php echo e(ucfirst($partner->verification_status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($partner->rating_avg); ?></td>
                        <td><?php echo e($partner->completed_deliveries_count); ?></td>
                        <td><?php echo e($partner->currentHomeCity?->name ?? '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($partner->is_active ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'); ?>">
                                <?php echo e($partner->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="text-right">
                            <?php if($partner->trashed()): ?>
                                <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.delivery-partners.restore', $partner->id)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="link-quiet text-info">Restore</button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.delivery-partners.force-delete', $partner->id)); ?>" class="inline" onsubmit="return confirm('Permanently delete this partner? This cannot be undone.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Force delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(\App\Support\AdminAccess::canManageOrders()): ?>
                                    <a href="<?php echo e(route('admin.delivery-partners.edit', $partner)); ?>" class="link-quiet">Edit</a>
                                <?php endif; ?>
                                <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.delivery-partners.destroy', $partner)); ?>" class="inline" onsubmit="return confirm('Delete this delivery partner?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">
                            <div class="empty-state">No delivery partners found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($partners->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/delivery-partners/index.blade.php ENDPATH**/ ?>