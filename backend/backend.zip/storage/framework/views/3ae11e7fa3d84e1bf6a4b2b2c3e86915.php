<?php $__env->startSection('title', 'Pricing rules'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $ruleTypeLabels = [
            'base' => 'Base fare',
            'weight_slab' => 'Weight slab',
            'peak_hour' => 'Peak hour surcharge',
            'platform_fee' => 'Platform fee',
            'tax' => 'Tax',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Pricing rules</h2>
            <p class="page-subtitle">Manage fare, surcharge, and tax rules across routes.</p>
        </div>
        <?php if(\App\Support\AdminAccess::canManagePricing()): ?>
            <a href="<?php echo e(route('admin.pricing-rules.create')); ?>" class="btn-primary">Add pricing rule</a>
        <?php endif; ?>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <select name="route_id" class="form-input w-56">
                <option value="">All routes</option>
                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($route->id); ?>" <?php if(($filters['route_id'] ?? '') == $route->id): echo 'selected'; endif; ?>>
                        <?php echo e($route->originStation?->name); ?> &rarr; <?php echo e($route->destinationStation?->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="rule_type" class="form-input w-48">
                <option value="">All types</option>
                <?php $__currentLoopData = $ruleTypeLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(($filters['rule_type'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Route</th>
                    <th>Type</th>
                    <th>Weight range</th>
                    <th>Amount</th>
                    <th>Percentage</th>
                    <th>Effective from</th>
                    <th>Effective to</th>
                    <th>Active</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pricingRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($rule->route): ?>
                                <?php echo e($rule->route->originStation?->name); ?> &rarr; <?php echo e($rule->route->destinationStation?->name); ?>

                            <?php else: ?>
                                <span class="text-text-secondary">Global</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($ruleTypeLabels[$rule->rule_type] ?? $rule->rule_type); ?></td>
                        <td>
                            <?php if($rule->min_weight_grams !== null || $rule->max_weight_grams !== null): ?>
                                <?php echo e($rule->min_weight_grams ?? 0); ?>g &ndash; <?php echo e($rule->max_weight_grams ?? '∞'); ?>g
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($rule->amount_paise !== null ? '₹' . number_format($rule->amount_paise / 100, 2) : '—'); ?></td>
                        <td><?php echo e($rule->percentage !== null ? $rule->percentage . '%' : '—'); ?></td>
                        <td class="text-caption text-text-secondary"><?php echo e($rule->effective_from?->format('Y-m-d H:i')); ?></td>
                        <td class="text-caption text-text-secondary"><?php echo e($rule->effective_to?->format('Y-m-d H:i') ?? '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($rule->is_active ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'); ?>">
                                <?php echo e($rule->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="text-right">
                            <?php if(\App\Support\AdminAccess::canManagePricing()): ?>
                                <a href="<?php echo e(route('admin.pricing-rules.edit', $rule)); ?>" class="link-quiet">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.pricing-rules.destroy', $rule)); ?>" class="inline" onsubmit="return confirm('Delete this pricing rule?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="ml-2 link-quiet text-danger">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">
                            <div class="empty-state">No pricing rules found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($pricingRules->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/pricing-rules/index.blade.php ENDPATH**/ ?>