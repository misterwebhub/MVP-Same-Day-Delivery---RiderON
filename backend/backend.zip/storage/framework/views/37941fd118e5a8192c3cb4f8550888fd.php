<?php $__env->startSection('title', 'Routes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h2 class="page-title">Routes</h2>
            <p class="page-subtitle">Manage delivery routes between stations.</p>
        </div>
        <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
            <a href="<?php echo e(route('admin.routes.create')); ?>" class="btn-primary">Add route</a>
        <?php endif; ?>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex items-center gap-2">
            <select name="origin_station_id" class="form-input w-48">
                <option value="">Any origin</option>
                <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($station->id); ?>" <?php if(($filters['origin_station_id'] ?? null) == $station->id): echo 'selected'; endif; ?>><?php echo e($station->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="destination_station_id" class="form-input w-48">
                <option value="">Any destination</option>
                <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($station->id); ?>" <?php if(($filters['destination_station_id'] ?? null) == $station->id): echo 'selected'; endif; ?>><?php echo e($station->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="trashed" class="form-input w-40">
                <option value="">Active only</option>
                <option value="with" <?php if(($filters['trashed'] ?? null) === 'with'): echo 'selected'; endif; ?>>With trashed</option>
                <option value="only" <?php if(($filters['trashed'] ?? null) === 'only'): echo 'selected'; endif; ?>>Trashed only</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Distance (km)</th>
                    <th>Duration (min)</th>
                    <th>Cutoff</th>
                    <th>Active</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($route->originStation?->name); ?></td>
                        <td><?php echo e($route->destinationStation?->name); ?></td>
                        <td><?php echo e($route->distance_km); ?></td>
                        <td><?php echo e($route->estimated_duration_minutes); ?></td>
                        <td><?php echo e($route->cutoff_time); ?></td>
                        <td>
                            <span class="badge <?php echo e($route->is_active ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'); ?>">
                                <?php echo e($route->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="text-right">
                            <?php if(\App\Support\AdminAccess::canManageMasterData()): ?>
                                <?php if($route->trashed()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.routes.restore', $route->id)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="link-quiet text-info">Restore</button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.routes.force-delete', $route->id)); ?>" class="inline" onsubmit="return confirm('Permanently delete this route? This cannot be undone.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Force delete</button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.routes.edit', $route)); ?>" class="link-quiet">Edit / Schedules</a>
                                    <form method="POST" action="<?php echo e(route('admin.routes.destroy', $route)); ?>" class="inline" onsubmit="return confirm('Delete this route?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="ml-2 link-quiet text-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">No routes found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($routes->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/routes/index.blade.php ENDPATH**/ ?>