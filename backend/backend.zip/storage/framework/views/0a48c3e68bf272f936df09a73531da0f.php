<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h2 class="page-title">Welcome back, <?php echo e(explode(' ', $user->name)[0]); ?></h2>
            <p class="page-subtitle">Here's what's happening across RiderON today.</p>
        </div>
        <div class="chip">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            <?php echo e(now()->format('D, d M Y')); ?>

        </div>
    </div>

    <div class="space-y-8">
        <section>
            <h2 class="mb-3 text-h2 font-heading text-text-primary">Today's bookings</h2>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <?php echo $__env->make('admin.components.stat-card', ['label' => "Today's bookings", 'value' => $bookingsCount, 'icon' => 'chart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => "Today's revenue", 'value' => '₹'.number_format($revenuePaise / 100, 2), 'icon' => 'money'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', [
                    'label' => 'Awaiting partner assignment',
                    'value' => $pendingAssignment,
                    'color' => $pendingAssignment > 0 ? 'warning' : 'success',
                    'icon' => 'clock',
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>

        <section>
            <h2 class="mb-3 text-h2 font-heading text-text-primary">Delivery funnel (today)</h2>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Booked', 'value' => $funnel['booked'], 'icon' => 'chart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Rider assigned', 'value' => $funnel['rider_assigned'], 'color' => 'info', 'icon' => 'truck'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'In transit', 'value' => $funnel['in_transit'], 'color' => 'info', 'icon' => 'truck'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Delivered / completed', 'value' => $funnel['delivered_completed'], 'color' => 'success', 'icon' => 'check'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Exceptions', 'value' => $funnel['exceptions'], 'color' => 'danger', 'icon' => 'alert'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>

        <section>
            <h2 class="mb-3 text-h2 font-heading text-text-primary">Active riders</h2>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Active partners', 'value' => $activePartners, 'icon' => 'user'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Verified partners', 'value' => $verifiedPartners, 'color' => 'success', 'icon' => 'shield'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('admin.components.stat-card', ['label' => 'Currently on a delivery', 'value' => $onDeliveryPartners, 'color' => 'info', 'icon' => 'truck'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>

        <section>
            <div class="card flex items-center gap-4">
                <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-h2 font-heading text-white">
                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                </span>
                <div>
                    <p class="text-caption text-text-secondary">Signed in as</p>
                    <p class="text-h2 font-heading text-text-primary"><?php echo e($user->name); ?> <span class="text-body font-normal text-text-secondary">(<?php echo e(ucfirst($user->role)); ?>)</span></p>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>