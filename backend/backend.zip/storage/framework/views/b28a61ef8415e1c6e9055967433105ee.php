<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusColors = [
            'COMPLETED' => 'bg-success/10 text-success',
            'DELIVERED' => 'bg-success/10 text-success',
            'CANCELLED' => 'bg-danger/10 text-danger',
            'PAYMENT_FAILED' => 'bg-danger/10 text-danger',
            'DISPUTED' => 'bg-danger/10 text-danger',
            'FAILED_DELIVERY' => 'bg-danger/10 text-danger',
            'REFUND_PENDING' => 'bg-warning/10 text-warning',
            'REFUNDED' => 'bg-warning/10 text-warning',
            'RIDER_ASSIGNMENT_PENDING' => 'bg-warning/10 text-warning',
        ];
    ?>

    <div class="page-header">
        <div>
            <h2 class="page-title">Orders</h2>
            <p class="page-subtitle">Track and manage all customer deliveries.</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="flex flex-wrap items-center gap-2">
            <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Search reference / phone" class="form-input w-56">
            <select name="status" class="form-input w-56">
                <option value="">All statuses</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="date" name="booking_date" value="<?php echo e($filters['booking_date'] ?? ''); ?>" class="form-input w-40">
            <select name="trashed" class="form-input w-40">
                <option value="">Active only</option>
                <option value="with" <?php if(($filters['trashed'] ?? null) === 'with'): echo 'selected'; endif; ?>>With trashed</option>
                <option value="only" <?php if(($filters['trashed'] ?? null) === 'only'): echo 'selected'; endif; ?>>Trashed only</option>
            </select>
            <button type="submit" class="btn-secondary">Filter</button>
        </form>
    </div>

    <div class="table-shell">
        <table>
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Customer</th>
                    <th>Route</th>
                    <th>Partner</th>
                    <th>Status</th>
                    <th>Booking date</th>
                    <th>Amount</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium"><?php echo e($order->booking_reference); ?></td>
                        <td><?php echo e($order->customer?->name); ?></td>
                        <td>
                            <?php echo e($order->route?->originStation?->name ?? '—'); ?> → <?php echo e($order->route?->destinationStation?->name ?? '—'); ?>

                        </td>
                        <td><?php echo e($order->partner?->user?->name ?? 'Unassigned'); ?></td>
                        <td>
                            <span class="badge <?php echo e($statusColors[$order->status] ?? 'bg-info/10 text-info'); ?>">
                                <?php echo e($order->status); ?>

                            </span>
                        </td>
                        <td><?php echo e(optional($order->booking_date)->format('Y-m-d')); ?></td>
                        <td>₹<?php echo e(number_format($order->total_amount_paise / 100, 2)); ?></td>
                        <td class="text-right">
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="link-quiet">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">
                            <div class="empty-state">No orders found.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($orders->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>