<?php $__env->startSection('title', 'Order ' . $order->booking_reference); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $statusColors = [
            \App\Constants\OrderStatus::PAYMENT_PENDING => 'bg-warning/10 text-warning',
            \App\Constants\OrderStatus::RIDER_ASSIGNMENT_PENDING => 'bg-info/10 text-info',
            \App\Constants\OrderStatus::DISPUTED => 'bg-danger/10 text-danger',
            \App\Constants\OrderStatus::REFUND_PENDING => 'bg-warning/10 text-warning',
            \App\Constants\OrderStatus::CANCELLED => 'bg-danger/10 text-danger',
            \App\Constants\OrderStatus::DELIVERED => 'bg-success/10 text-success',
            \App\Constants\OrderStatus::COMPLETED => 'bg-success/10 text-success',
        ];
        $statusColor = $statusColors[$order->status] ?? 'bg-border text-text-secondary';
    ?>

    <div class="mb-4">
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="link-quiet inline-flex items-center gap-1">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
            Back to orders
        </a>
    </div>

    <div class="page-header">
        <div>
            <div class="flex items-center gap-3">
                <h2 class="text-h1 font-heading text-text-primary"><?php echo e($order->booking_reference); ?></h2>
                <span class="badge <?php echo e($statusColor); ?>"><?php echo e(str_replace('_', ' ', $order->status)); ?></span>
            </div>
            <p class="page-subtitle">Placed <?php echo e(optional($order->booking_date)->format('D, d M Y')); ?> &middot; <?php echo e($order->customer?->name); ?></p>
        </div>
        <div class="flex gap-3">
            <div class="chip">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V6m0 10v2"/><circle cx="12" cy="12" r="9"/></svg>
                ₹<?php echo e(number_format($order->total_amount_paise / 100, 2)); ?>

            </div>
            <div class="chip">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M1 3h13v13H1V3zm13 5h4l3 3v5h-7V8z"/></svg>
                <?php echo e($order->partner?->user?->name ?? 'Unassigned'); ?>

            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div class="space-y-6 lg:col-span-2">
            <div class="card">
                <h3 class="mb-4 text-body-strong text-text-primary">Order details</h3>
                <dl class="grid grid-cols-1 gap-x-6 gap-y-4 text-body sm:grid-cols-2">
                    <div>
                        <dt class="text-caption text-text-secondary">Customer</dt>
                        <dd class="font-medium"><?php echo e($order->customer?->name); ?> <span class="font-normal text-text-secondary">(<?php echo e($order->customer?->phone); ?>)</span></dd>
                    </div>
                    <div>
                        <dt class="text-caption text-text-secondary">Route</dt>
                        <dd class="font-medium"><?php echo e($order->route?->originStation?->name ?? '—'); ?> <span class="text-text-secondary">&rarr;</span> <?php echo e($order->route?->destinationStation?->name ?? '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-caption text-text-secondary">Sender</dt>
                        <dd class="font-medium"><?php echo e($order->sender_name); ?> <span class="font-normal text-text-secondary">&middot; <?php echo e($order->sender_phone); ?></span></dd>
                    </div>
                    <div>
                        <dt class="text-caption text-text-secondary">Receiver</dt>
                        <dd class="font-medium"><?php echo e($order->receiver_name); ?> <span class="font-normal text-text-secondary">&middot; <?php echo e($order->receiver_phone); ?></span></dd>
                    </div>
                    <div>
                        <dt class="text-caption text-text-secondary">Amount</dt>
                        <dd class="font-medium">₹<?php echo e(number_format($order->total_amount_paise / 100, 2)); ?> <?php echo e($order->currency); ?></dd>
                    </div>
                    <div>
                        <dt class="text-caption text-text-secondary">Booking date</dt>
                        <dd class="font-medium"><?php echo e(optional($order->booking_date)->format('Y-m-d')); ?></dd>
                    </div>
                    <?php if($order->cancelled_at): ?>
                        <div>
                            <dt class="text-caption text-text-secondary">Cancelled at</dt>
                            <dd class="font-medium text-danger"><?php echo e($order->cancelled_at); ?> <span class="font-normal text-text-secondary">(<?php echo e($order->cancelled_by); ?>)</span></dd>
                        </div>
                        <div class="sm:col-span-2">
                            <dt class="text-caption text-text-secondary">Cancellation reason</dt>
                            <dd class="font-medium"><?php echo e($order->cancellation_reason); ?></dd>
                        </div>
                    <?php endif; ?>
                    <?php if($order->delivered_at): ?>
                        <div>
                            <dt class="text-caption text-text-secondary">Delivered at</dt>
                            <dd class="font-medium text-success"><?php echo e($order->delivered_at); ?></dd>
                        </div>
                    <?php endif; ?>
                    <?php if($order->completed_at): ?>
                        <div>
                            <dt class="text-caption text-text-secondary">Completed at</dt>
                            <dd class="font-medium text-success"><?php echo e($order->completed_at); ?></dd>
                        </div>
                    <?php endif; ?>
                </dl>
            </div>

            <div class="card">
                <h3 class="mb-4 text-body-strong text-text-primary">Status history</h3>
                <?php if($order->statusHistory->isEmpty()): ?>
                    <div class="empty-state">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-text-secondary/50" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        No history yet.
                    </div>
                <?php else: ?>
                    <div class="timeline">
                        <?php $__currentLoopData = $order->statusHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="timeline-item">
                                <span class="timeline-dot">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg>
                                </span>
                                <div class="flex-1 pt-0.5">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <?php if($entry->from_status): ?>
                                            <span class="text-caption text-text-secondary"><?php echo e(str_replace('_', ' ', $entry->from_status)); ?></span>
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-text-secondary" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                                        <?php endif; ?>
                                        <span class="text-body-strong text-text-primary"><?php echo e(str_replace('_', ' ', $entry->to_status)); ?></span>
                                    </div>
                                    <p class="mt-0.5 text-caption text-text-secondary">by <?php echo e(ucfirst($entry->changed_by_type)); ?> &middot; <?php echo e($entry->created_at); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card">
                <h3 class="mb-4 text-body-strong text-text-primary">Activity &amp; evidence</h3>
                <p class="mb-4 text-caption text-text-secondary">Every notable event on this order — who did it, from what IP, and (rider-side only) GPS distance from the relevant station. Admin-only; never shown to the customer or partner apps.</p>
                <?php if($order->activityLogs->isEmpty()): ?>
                    <div class="empty-state">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-text-secondary/50" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        No activity recorded yet.
                    </div>
                <?php else: ?>
                    <div class="timeline">
                        <?php $__currentLoopData = $order->activityLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="timeline-item">
                                <span class="timeline-dot">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg>
                                </span>
                                <div class="flex-1 pt-0.5">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <span class="text-body-strong text-text-primary"><?php echo e(str_replace('_', ' ', $log->event)); ?></span>
                                        <span class="text-caption text-text-secondary">by <?php echo e(ucfirst($log->actor_type)); ?><?php echo e($log->actor ? ' · '.$log->actor->name : ''); ?></span>
                                    </div>
                                    <p class="mt-0.5 text-caption text-text-secondary"><?php echo e($log->created_at); ?></p>
                                    <div class="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-caption text-text-secondary">
                                        <?php if($log->ip_address): ?>
                                            <span>IP: <span class="font-mono text-text-primary"><?php echo e($log->ip_address); ?></span></span>
                                        <?php endif; ?>
                                        <?php if($log->latitude !== null && $log->longitude !== null): ?>
                                            <span>GPS: <span class="font-mono text-text-primary"><?php echo e($log->latitude); ?>, <?php echo e($log->longitude); ?></span></span>
                                        <?php endif; ?>
                                        <?php if($log->distance_from_target_meters !== null): ?>
                                            <span class="<?php echo e($log->distance_from_target_meters > 500 ? 'text-warning font-medium' : ''); ?>"><?php echo e($log->distance_from_target_meters); ?>m from station</span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($log->metadata): ?>
                                        <p class="mt-0.5 text-caption text-text-secondary"><?php echo e(json_encode($log->metadata)); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if($order->pickup_proof_photo_path || $order->delivery_proof_photo_path): ?>
                    <div class="mt-4 grid grid-cols-2 gap-3">
                        <?php if($order->pickup_proof_photo_path): ?>
                            <a href="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($order->pickup_proof_photo_path)); ?>" target="_blank" class="block">
                                <p class="mb-1 text-micro uppercase tracking-wide text-text-secondary">Pickup proof</p>
                                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($order->pickup_proof_photo_path)); ?>" class="h-24 w-full rounded-md border border-border object-cover" alt="Pickup proof photo">
                            </a>
                        <?php endif; ?>
                        <?php if($order->delivery_proof_photo_path): ?>
                            <a href="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($order->delivery_proof_photo_path)); ?>" target="_blank" class="block">
                                <p class="mb-1 text-micro uppercase tracking-wide text-text-secondary">Delivery proof</p>
                                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($order->delivery_proof_photo_path)); ?>" class="h-24 w-full rounded-md border border-border object-cover" alt="Delivery proof photo">
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="space-y-4">
            <?php if(\App\Support\AdminAccess::canManageOrders()): ?>
                <div class="action-card border-l-secondary">
                    <h3 class="text-body-strong text-text-primary">Pickup &amp; delivery OTP</h3>
                    <p class="text-caption text-text-secondary">Generate a code instantly for testing — skips SMS delivery. Use it in the partner app to verify pickup/delivery.</p>

                    <?php if(session('generatedOtp')): ?>
                        <?php $g = session('generatedOtp'); ?>
                        <div class="rounded-md border border-primary/30 bg-primary/5 p-3">
                            <p class="text-micro uppercase tracking-wide text-primary"><?php echo e(ucfirst($g['purpose'])); ?> OTP</p>
                            <p class="mt-1 font-mono text-h1 tracking-[0.3em] text-text-primary"><?php echo e($g['otp']); ?></p>
                            <p class="mt-1 text-caption text-text-secondary">for <?php echo e($g['phone']); ?> &middot; expires <?php echo e($g['expires_at']->format('H:i:s')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="space-y-2 text-caption">
                        <div class="flex items-center justify-between rounded-md border border-border px-3 py-2">
                            <div>
                                <p class="font-medium text-text-primary">Pickup</p>
                                <?php if($latestPickupOtp): ?>
                                    <p class="text-text-secondary">
                                        <?php echo e($latestPickupOtp->verified_at ? 'Verified' : ($latestPickupOtp->expires_at->isPast() ? 'Expired' : 'Pending')); ?>

                                        &middot; <?php echo e($latestPickupOtp->phone); ?>

                                    </p>
                                <?php else: ?>
                                    <p class="text-text-secondary">Not generated yet</p>
                                <?php endif; ?>
                            </div>
                            <form method="POST" action="<?php echo e(route('admin.orders.otp.generate', [$order, 'pickup'])); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-secondary"><?php echo e($latestPickupOtp && ! $latestPickupOtp->verified_at ? 'Regenerate' : 'Generate'); ?></button>
                            </form>
                        </div>

                        <div class="flex items-center justify-between rounded-md border border-border px-3 py-2">
                            <div>
                                <p class="font-medium text-text-primary">Delivery</p>
                                <?php if($latestDeliveryOtp): ?>
                                    <p class="text-text-secondary">
                                        <?php echo e($latestDeliveryOtp->verified_at ? 'Verified' : ($latestDeliveryOtp->expires_at->isPast() ? 'Expired' : 'Pending')); ?>

                                        &middot; <?php echo e($latestDeliveryOtp->phone); ?>

                                    </p>
                                <?php else: ?>
                                    <p class="text-text-secondary">Not generated yet</p>
                                <?php endif; ?>
                            </div>
                            <form method="POST" action="<?php echo e(route('admin.orders.otp.generate', [$order, 'delivery'])); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-secondary"><?php echo e($latestDeliveryOtp && ! $latestDeliveryOtp->verified_at ? 'Regenerate' : 'Generate'); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(\App\Support\AdminAccess::canManageOrders() && ! \App\Constants\OrderStatus::isTerminal($order->status)): ?>
                <div class="action-card border-l-info">
                    <h3 class="text-body-strong text-text-primary"><?php echo e($order->partner_id === null ? 'Assign partner' : 'Reassign partner'); ?></h3>
                    <?php if($order->partner): ?>
                        <p class="text-caption text-text-secondary mb-3">
                            Currently assigned: <?php echo e($order->partner->user?->name); ?> (<?php echo e($order->partner->partner_code); ?>)
                        </p>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('admin.orders.assign-partner', $order)); ?>" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <select name="partner_id" required class="form-input">
                            <option value="">Select a partner</option>
                            <?php $__currentLoopData = $eligiblePartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($partner->id); ?>" <?php if($partner->id === $order->partner_id): echo 'selected'; endif; ?>><?php echo e($partner->user?->name); ?> (<?php echo e($partner->partner_code); ?>) — <?php echo e($partner->completed_deliveries_count); ?> deliveries</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($eligiblePartners->isEmpty()): ?>
                            <p class="text-caption text-warning">No eligible partners available right now.</p>
                        <?php endif; ?>
                        <button type="submit" class="btn-primary w-full"><?php echo e($order->partner_id === null ? 'Assign' : 'Reassign'); ?></button>
                    </form>
                </div>
            <?php endif; ?>

            <?php if(\App\Support\AdminAccess::canManageOrders() && ! \App\Constants\OrderStatus::isTerminal($order->status)): ?>
                <div class="action-card border-l-danger">
                    <h3 class="text-body-strong text-text-primary">Force cancel</h3>
                    <form method="POST" action="<?php echo e(route('admin.orders.force-cancel', $order)); ?>" class="space-y-3" onsubmit="return confirm('Force cancel this order?');">
                        <?php echo csrf_field(); ?>
                        <textarea name="reason" required placeholder="Cancellation reason" class="form-input"></textarea>
                        <button type="submit" class="btn-secondary w-full text-danger">Cancel order</button>
                    </form>
                </div>
            <?php endif; ?>

            <?php if(\App\Support\AdminAccess::canManageOrders() && in_array($order->status, app(\App\StateMachines\OrderStateMachine::class)->allowedSourceStatuses(\App\Constants\OrderStatus::DISPUTED), true)): ?>
                <div class="action-card border-l-warning">
                    <h3 class="text-body-strong text-text-primary">Mark disputed</h3>
                    <form method="POST" action="<?php echo e(route('admin.orders.mark-disputed', $order)); ?>" class="space-y-3" onsubmit="return confirm('Mark this order disputed?');">
                        <?php echo csrf_field(); ?>
                        <textarea name="reason" required placeholder="Dispute reason" class="form-input"></textarea>
                        <button type="submit" class="btn-secondary w-full text-warning">Mark disputed</button>
                    </form>
                </div>
            <?php endif; ?>

            <?php if(\App\Support\AdminAccess::canApproveRefunds() && $order->status === \App\Constants\OrderStatus::REFUND_PENDING): ?>
                <div class="action-card border-l-primary">
                    <h3 class="text-body-strong text-text-primary">Approve refund</h3>
                    <form method="POST" action="<?php echo e(route('admin.orders.approve-refund', $order)); ?>" class="space-y-3" onsubmit="return confirm('Approve refund for this order?');">
                        <?php echo csrf_field(); ?>
                        <input type="number" name="amount_paise" min="1" value="<?php echo e($order->total_amount_paise); ?>" required class="form-input" placeholder="Refund amount (paise)">
                        <textarea name="reason" required placeholder="Refund reason" class="form-input"></textarea>
                        <button type="submit" class="btn-primary w-full">Approve refund</button>
                    </form>
                </div>
            <?php endif; ?>

            <?php if(! \App\Support\AdminAccess::canManageOrders() && ! \App\Support\AdminAccess::canApproveRefunds()): ?>
                <div class="card">
                    <p class="text-caption text-text-secondary">No actions available for your role on this order.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\myproject\rideron\backend\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>