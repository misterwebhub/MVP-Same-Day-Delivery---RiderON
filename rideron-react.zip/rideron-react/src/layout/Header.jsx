import React from "react";
import { ArrowRight, MessageCircle } from "lucide-react";
import Logo from "./Logo";
import { navItems } from "../data/navigation";

export default function Header({ activePage = "home", onNavigate }) {
  const handleNavigate = (event, item) => {
    event.preventDefault();
    onNavigate?.(item.page, item.hash);
  };

  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <Logo onClick={(event) => handleNavigate(event, { page: "home" })} />
        <nav className="desktop-nav">
          {navItems.map((item) => (
            <a
              key={item.label}
              className={item.page === activePage && !item.hash ? "active" : ""}
              href={item.hash ? `#${item.hash}` : `#${item.page}`}
              onClick={(event) => handleNavigate(event, item)}
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="header-actions">
          <div className="phone-chip">
            <MessageCircle size={25} />
            <span>
              <strong>+91 700 123 4567</strong>
              <small>Mon - Sat, 8AM - 8PM</small>
            </span>
          </div>
          <a className="nav-cta" href="#book-parcel" onClick={(event) => handleNavigate(event, { page: "home", hash: "book-parcel" })}>
            Book Now <ArrowRight size={17} />
          </a>
        </div>
      </div>
    </header>
  );
}
