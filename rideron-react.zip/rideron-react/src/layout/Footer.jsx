import React from "react";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import Logo from "./Logo";
import { navItems } from "../data/navigation";

function FooterLinks({ title, links, onNavigate }) {
  return (
    <div className="footer-links">
      <h3>{title}</h3>
      {links.map((link) => (
        <a
          href={link.hash ? `#${link.hash}` : `#${link.page || link.label}`}
          key={link.label}
          onClick={(event) => {
            if (link.page) {
              event.preventDefault();
              onNavigate?.(link.page, link.hash);
            }
          }}
        >
          {link.label}
        </a>
      ))}
    </div>
  );
}

export default function Footer({ onNavigate }) {
  return (
    <footer className="footer" id="contact-us">
      <div className="footer-cta">
        <div className="container footer-cta-inner">
          <div>
            <h2>Need to send a parcel today?</h2>
            <p>Book now and experience fast, safe & same-day delivery.</p>
            <a href="#book-parcel" className="primary-btn" onClick={(event) => {
              event.preventDefault();
              onNavigate?.("home", "book-parcel");
            }}>
              Book Your Parcel Now
            </a>
          </div>
          <div className="footer-train" />
        </div>
      </div>
      <div className="container footer-grid">
        <div className="footer-brand">
          <Logo onClick={(event) => {
            event.preventDefault();
            onNavigate?.("home");
          }} />
          <p>Fast, safe & affordable station-to-station parcel delivery between Kanpur Central and Lucknow Charbagh.</p>
          <div className="socials">
            <span>wa</span>
            <span>ig</span>
            <span>fb</span>
          </div>
        </div>

        <FooterLinks title="Quick Links" links={navItems} onNavigate={onNavigate} />
        <FooterLinks
          title="Support"
          links={[
            { label: "Contact Us", page: "contact" },
            { label: "FAQ", page: "services" },
            { label: "Terms & Conditions", page: "services" },
            { label: "Privacy Policy", page: "services" }
          ]}
          onNavigate={onNavigate}
        />

        <div className="footer-contact">
          <h3>Contact Us</h3>
          <p><Phone size={13} /> +91 700 123 4567</p>
          <p><Mail size={13} /> support@rideron.in</p>
          <p><MessageCircle size={13} /> Mon - Sat, 8AM - 8PM</p>
          <p><MapPin size={13} /> Kanpur, Uttar Pradesh</p>
        </div>
      </div>
      <div className="copyright">Copyright 2024 RiderON. All Rights Reserved.</div>
    </footer>
  );
}
