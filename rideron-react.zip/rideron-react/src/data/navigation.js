export const navItems = [
  { label: "Home", page: "home" },
  { label: "Book Parcel", page: "home", hash: "book-parcel" },
  { label: "Services", page: "services" },
  { label: "Pricing", page: "home", hash: "pricing" },
  { label: "About Us", page: "about" },
  { label: "Contact Us", page: "contact" }
];
