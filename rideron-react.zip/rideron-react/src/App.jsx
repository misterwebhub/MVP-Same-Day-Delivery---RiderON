import React from "react";
import HomePage from "./pages/Home/HomePage";
import AboutPage from "./pages/About/AboutPage";
import ContactPage from "./pages/Contact/ContactPage";
import ServicesPage from "./pages/Services/ServicesPage";

const pages = {
  home: HomePage,
  about: AboutPage,
  services: ServicesPage,
  contact: ContactPage
};

export default function App() {
  const getPageFromHash = () => {
    const hash = window.location.hash.replace("#", "");
    return pages[hash] ? hash : "home";
  };

  const [activePage, setActivePage] = React.useState(getPageFromHash);

  const navigate = (page, hash) => {
    setActivePage(page);
    window.history.replaceState(null, "", hash ? `#${hash}` : `#${page}`);
    window.setTimeout(() => {
      if (hash) {
        document.getElementById(hash)?.scrollIntoView({ behavior: "smooth", block: "start" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }, 0);
  };

  React.useEffect(() => {
    const onHashChange = () => setActivePage(getPageFromHash());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const Page = pages[activePage] || HomePage;

  return <Page activePage={activePage} onNavigate={navigate} />;
}
